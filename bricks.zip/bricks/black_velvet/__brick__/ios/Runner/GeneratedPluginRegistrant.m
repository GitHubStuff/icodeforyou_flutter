//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<shared_preferences_foundation/SharedPreferencesPlugin.h>)
#import <shared_preferences_foundation/SharedPreferencesPlugin.h>
#else
@import shared_preferences_foundation;
#endif

#if __has_include(<status_bar_chameleon/StatusBarChameleonPlugin.h>)
#import <status_bar_chameleon/StatusBarChameleonPlugin.h>
#else
@import status_bar_chameleon;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [SharedPreferencesPlugin registerWithRegistrar:[registry registrarForPlugin:@"SharedPreferencesPlugin"]];
  [StatusBarChameleonPlugin registerWithRegistrar:[registry registrarForPlugin:@"StatusBarChameleonPlugin"]];
}

@end

// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $GlossaryItemsTable extends GlossaryItems
    with TableInfo<$GlossaryItemsTable, GlossaryItem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GlossaryItemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    hasAutoIncrement: true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'PRIMARY KEY AUTOINCREMENT',
    ),
  );
  static const VerificationMeta _createdTimeStampMeta = const VerificationMeta(
    'createdTimeStamp',
  );
  @override
  late final GeneratedColumn<int> createdTimeStamp = GeneratedColumn<int>(
    'created_time_stamp',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
    defaultConstraints: GeneratedColumn.constraintIsAlways('UNIQUE'),
  );
  static const VerificationMeta _tagNameMeta = const VerificationMeta(
    'tagName',
  );
  @override
  late final GeneratedColumn<String> tagName = GeneratedColumn<String>(
    'tag_name',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
    defaultConstraints: GeneratedColumn.constraintIsAlways('UNIQUE'),
  );
  static const VerificationMeta _descriptionMeta = const VerificationMeta(
    'description',
  );
  @override
  late final GeneratedColumn<String> description = GeneratedColumn<String>(
    'description',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _colorIntMeta = const VerificationMeta(
    'colorInt',
  );
  @override
  late final GeneratedColumn<int> colorInt = GeneratedColumn<int>(
    'color_int',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
    defaultConstraints: GeneratedColumn.constraintIsAlways('UNIQUE'),
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    createdTimeStamp,
    tagName,
    description,
    colorInt,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'glossary_items';
  @override
  VerificationContext validateIntegrity(
    Insertable<GlossaryItem> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('created_time_stamp')) {
      context.handle(
        _createdTimeStampMeta,
        createdTimeStamp.isAcceptableOrUnknown(
          data['created_time_stamp']!,
          _createdTimeStampMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_createdTimeStampMeta);
    }
    if (data.containsKey('tag_name')) {
      context.handle(
        _tagNameMeta,
        tagName.isAcceptableOrUnknown(data['tag_name']!, _tagNameMeta),
      );
    } else if (isInserting) {
      context.missing(_tagNameMeta);
    }
    if (data.containsKey('description')) {
      context.handle(
        _descriptionMeta,
        description.isAcceptableOrUnknown(
          data['description']!,
          _descriptionMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_descriptionMeta);
    }
    if (data.containsKey('color_int')) {
      context.handle(
        _colorIntMeta,
        colorInt.isAcceptableOrUnknown(data['color_int']!, _colorIntMeta),
      );
    } else if (isInserting) {
      context.missing(_colorIntMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GlossaryItem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GlossaryItem(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      )!,
      createdTimeStamp: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}created_time_stamp'],
      )!,
      tagName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tag_name'],
      )!,
      description: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}description'],
      )!,
      colorInt: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}color_int'],
      )!,
    );
  }

  @override
  $GlossaryItemsTable createAlias(String alias) {
    return $GlossaryItemsTable(attachedDatabase, alias);
  }
}

class GlossaryItem extends DataClass implements Insertable<GlossaryItem> {
  /// Auto-incrementing primary key.
  final int id;

  /// Creation time in milliseconds since epoch.
  final int createdTimeStamp;

  /// Tag identifying this glossary item. Unique across all items.
  final String tagName;

  /// Human-readable description of the item.
  final String description;

  /// Display color encoded as an ARGB integer. Unique across all items.
  final int colorInt;
  const GlossaryItem({
    required this.id,
    required this.createdTimeStamp,
    required this.tagName,
    required this.description,
    required this.colorInt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['created_time_stamp'] = Variable<int>(createdTimeStamp);
    map['tag_name'] = Variable<String>(tagName);
    map['description'] = Variable<String>(description);
    map['color_int'] = Variable<int>(colorInt);
    return map;
  }

  GlossaryItemsCompanion toCompanion(bool nullToAbsent) {
    return GlossaryItemsCompanion(
      id: Value(id),
      createdTimeStamp: Value(createdTimeStamp),
      tagName: Value(tagName),
      description: Value(description),
      colorInt: Value(colorInt),
    );
  }

  factory GlossaryItem.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GlossaryItem(
      id: serializer.fromJson<int>(json['id']),
      createdTimeStamp: serializer.fromJson<int>(json['createdTimeStamp']),
      tagName: serializer.fromJson<String>(json['tagName']),
      description: serializer.fromJson<String>(json['description']),
      colorInt: serializer.fromJson<int>(json['colorInt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'createdTimeStamp': serializer.toJson<int>(createdTimeStamp),
      'tagName': serializer.toJson<String>(tagName),
      'description': serializer.toJson<String>(description),
      'colorInt': serializer.toJson<int>(colorInt),
    };
  }

  GlossaryItem copyWith({
    int? id,
    int? createdTimeStamp,
    String? tagName,
    String? description,
    int? colorInt,
  }) => GlossaryItem(
    id: id ?? this.id,
    createdTimeStamp: createdTimeStamp ?? this.createdTimeStamp,
    tagName: tagName ?? this.tagName,
    description: description ?? this.description,
    colorInt: colorInt ?? this.colorInt,
  );
  GlossaryItem copyWithCompanion(GlossaryItemsCompanion data) {
    return GlossaryItem(
      id: data.id.present ? data.id.value : this.id,
      createdTimeStamp: data.createdTimeStamp.present
          ? data.createdTimeStamp.value
          : this.createdTimeStamp,
      tagName: data.tagName.present ? data.tagName.value : this.tagName,
      description: data.description.present
          ? data.description.value
          : this.description,
      colorInt: data.colorInt.present ? data.colorInt.value : this.colorInt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('GlossaryItem(')
          ..write('id: $id, ')
          ..write('createdTimeStamp: $createdTimeStamp, ')
          ..write('tagName: $tagName, ')
          ..write('description: $description, ')
          ..write('colorInt: $colorInt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, createdTimeStamp, tagName, description, colorInt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GlossaryItem &&
          other.id == this.id &&
          other.createdTimeStamp == this.createdTimeStamp &&
          other.tagName == this.tagName &&
          other.description == this.description &&
          other.colorInt == this.colorInt);
}

class GlossaryItemsCompanion extends UpdateCompanion<GlossaryItem> {
  final Value<int> id;
  final Value<int> createdTimeStamp;
  final Value<String> tagName;
  final Value<String> description;
  final Value<int> colorInt;
  const GlossaryItemsCompanion({
    this.id = const Value.absent(),
    this.createdTimeStamp = const Value.absent(),
    this.tagName = const Value.absent(),
    this.description = const Value.absent(),
    this.colorInt = const Value.absent(),
  });
  GlossaryItemsCompanion.insert({
    this.id = const Value.absent(),
    required int createdTimeStamp,
    required String tagName,
    required String description,
    required int colorInt,
  }) : createdTimeStamp = Value(createdTimeStamp),
       tagName = Value(tagName),
       description = Value(description),
       colorInt = Value(colorInt);
  static Insertable<GlossaryItem> custom({
    Expression<int>? id,
    Expression<int>? createdTimeStamp,
    Expression<String>? tagName,
    Expression<String>? description,
    Expression<int>? colorInt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (createdTimeStamp != null) 'created_time_stamp': createdTimeStamp,
      if (tagName != null) 'tag_name': tagName,
      if (description != null) 'description': description,
      if (colorInt != null) 'color_int': colorInt,
    });
  }

  GlossaryItemsCompanion copyWith({
    Value<int>? id,
    Value<int>? createdTimeStamp,
    Value<String>? tagName,
    Value<String>? description,
    Value<int>? colorInt,
  }) {
    return GlossaryItemsCompanion(
      id: id ?? this.id,
      createdTimeStamp: createdTimeStamp ?? this.createdTimeStamp,
      tagName: tagName ?? this.tagName,
      description: description ?? this.description,
      colorInt: colorInt ?? this.colorInt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (createdTimeStamp.present) {
      map['created_time_stamp'] = Variable<int>(createdTimeStamp.value);
    }
    if (tagName.present) {
      map['tag_name'] = Variable<String>(tagName.value);
    }
    if (description.present) {
      map['description'] = Variable<String>(description.value);
    }
    if (colorInt.present) {
      map['color_int'] = Variable<int>(colorInt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GlossaryItemsCompanion(')
          ..write('id: $id, ')
          ..write('createdTimeStamp: $createdTimeStamp, ')
          ..write('tagName: $tagName, ')
          ..write('description: $description, ')
          ..write('colorInt: $colorInt')
          ..write(')'))
        .toString();
  }
}

abstract class _$SinceWhenDatabase extends GeneratedDatabase {
  _$SinceWhenDatabase(QueryExecutor e) : super(e);
  $SinceWhenDatabaseManager get managers => $SinceWhenDatabaseManager(this);
  late final $GlossaryItemsTable glossaryItems = $GlossaryItemsTable(this);
  late final GlossaryItemsDao glossaryItemsDao = GlossaryItemsDao(
    this as SinceWhenDatabase,
  );
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [glossaryItems];
}

typedef $$GlossaryItemsTableCreateCompanionBuilder =
    GlossaryItemsCompanion Function({
      Value<int> id,
      required int createdTimeStamp,
      required String tagName,
      required String description,
      required int colorInt,
    });
typedef $$GlossaryItemsTableUpdateCompanionBuilder =
    GlossaryItemsCompanion Function({
      Value<int> id,
      Value<int> createdTimeStamp,
      Value<String> tagName,
      Value<String> description,
      Value<int> colorInt,
    });

class $$GlossaryItemsTableFilterComposer
    extends Composer<_$SinceWhenDatabase, $GlossaryItemsTable> {
  $$GlossaryItemsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get createdTimeStamp => $composableBuilder(
    column: $table.createdTimeStamp,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tagName => $composableBuilder(
    column: $table.tagName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get description => $composableBuilder(
    column: $table.description,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get colorInt => $composableBuilder(
    column: $table.colorInt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$GlossaryItemsTableOrderingComposer
    extends Composer<_$SinceWhenDatabase, $GlossaryItemsTable> {
  $$GlossaryItemsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get createdTimeStamp => $composableBuilder(
    column: $table.createdTimeStamp,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tagName => $composableBuilder(
    column: $table.tagName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get description => $composableBuilder(
    column: $table.description,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get colorInt => $composableBuilder(
    column: $table.colorInt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$GlossaryItemsTableAnnotationComposer
    extends Composer<_$SinceWhenDatabase, $GlossaryItemsTable> {
  $$GlossaryItemsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get createdTimeStamp => $composableBuilder(
    column: $table.createdTimeStamp,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tagName =>
      $composableBuilder(column: $table.tagName, builder: (column) => column);

  GeneratedColumn<String> get description => $composableBuilder(
    column: $table.description,
    builder: (column) => column,
  );

  GeneratedColumn<int> get colorInt =>
      $composableBuilder(column: $table.colorInt, builder: (column) => column);
}

class $$GlossaryItemsTableTableManager
    extends
        RootTableManager<
          _$SinceWhenDatabase,
          $GlossaryItemsTable,
          GlossaryItem,
          $$GlossaryItemsTableFilterComposer,
          $$GlossaryItemsTableOrderingComposer,
          $$GlossaryItemsTableAnnotationComposer,
          $$GlossaryItemsTableCreateCompanionBuilder,
          $$GlossaryItemsTableUpdateCompanionBuilder,
          (
            GlossaryItem,
            BaseReferences<
              _$SinceWhenDatabase,
              $GlossaryItemsTable,
              GlossaryItem
            >,
          ),
          GlossaryItem,
          PrefetchHooks Function()
        > {
  $$GlossaryItemsTableTableManager(
    _$SinceWhenDatabase db,
    $GlossaryItemsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$GlossaryItemsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$GlossaryItemsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$GlossaryItemsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<int> createdTimeStamp = const Value.absent(),
                Value<String> tagName = const Value.absent(),
                Value<String> description = const Value.absent(),
                Value<int> colorInt = const Value.absent(),
              }) => GlossaryItemsCompanion(
                id: id,
                createdTimeStamp: createdTimeStamp,
                tagName: tagName,
                description: description,
                colorInt: colorInt,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                required int createdTimeStamp,
                required String tagName,
                required String description,
                required int colorInt,
              }) => GlossaryItemsCompanion.insert(
                id: id,
                createdTimeStamp: createdTimeStamp,
                tagName: tagName,
                description: description,
                colorInt: colorInt,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$GlossaryItemsTableProcessedTableManager =
    ProcessedTableManager<
      _$SinceWhenDatabase,
      $GlossaryItemsTable,
      GlossaryItem,
      $$GlossaryItemsTableFilterComposer,
      $$GlossaryItemsTableOrderingComposer,
      $$GlossaryItemsTableAnnotationComposer,
      $$GlossaryItemsTableCreateCompanionBuilder,
      $$GlossaryItemsTableUpdateCompanionBuilder,
      (
        GlossaryItem,
        BaseReferences<_$SinceWhenDatabase, $GlossaryItemsTable, GlossaryItem>,
      ),
      GlossaryItem,
      PrefetchHooks Function()
    >;

class $SinceWhenDatabaseManager {
  final _$SinceWhenDatabase _db;
  $SinceWhenDatabaseManager(this._db);
  $$GlossaryItemsTableTableManager get glossaryItems =>
      $$GlossaryItemsTableTableManager(_db, _db.glossaryItems);
}

// packages/sincewhen_drift_framework/lib/src/database.dart

import 'package:drift/drift.dart';
import 'package:sincewhen_drift_framework/src/database/database_opening.dart'
    show SinceWhenDatabaseOpening;
import 'package:sincewhen_drift_framework/src/tables/glossary_items/glossary_items.dart'
    show GlossaryItems;
import 'package:sincewhen_drift_framework/src/tables/glossary_items/glossary_items_dao.dart'
    show GlossaryItemsDao;

part 'database.g.dart';

@DriftDatabase(tables: [GlossaryItems], daos: [GlossaryItemsDao])
class SinceWhenDatabase extends _$SinceWhenDatabase {
  /// Creates the database over [executor].
  SinceWhenDatabase(QueryExecutor executor) : super(executor);

  @override
  int get schemaVersion => 1;
}

final SinceWhenDatabase database = SinceWhenDatabaseOpening.inDocumentFolder(
  fileName: 'sincewhen.db',
);

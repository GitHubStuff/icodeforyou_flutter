// packages/sincewhen_drift_framework/lib/src/tables/glossary_items.dart

import 'package:drift/drift.dart';

/// Persisted glossary items tagged for SinceWhen tracking.
///
/// Each row pairs a unique [tagName] with its [description] and a unique
/// display color, recording when the item was created via
/// [createdTimeStamp].
class GlossaryItems extends Table {
  /// Auto-incrementing primary key.
  IntColumn get id => integer().autoIncrement()();

  /// Creation time in milliseconds since epoch.
  IntColumn get createdTimeStamp => integer().unique()();

  /// Tag identifying this glossary item. Unique across all items.
  TextColumn get tagName => text().unique()();

  /// Human-readable description of the item.
  TextColumn get description => text()();

  /// Display color encoded as an ARGB integer. Unique across all items.
  IntColumn get colorInt => integer().unique()();
}

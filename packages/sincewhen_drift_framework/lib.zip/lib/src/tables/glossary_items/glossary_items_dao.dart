// packages/sincewhen_drift_framework/lib/src/tables/glossary_items/glossary_items_dao.dart

import 'package:drift/drift.dart';
import 'package:sincewhen_drift_framework/src/database/database.dart'
    show $GlossaryItemsTable, GlossaryItem, SinceWhenDatabase;
import 'package:sincewhen_drift_framework/src/tables/glossary_items/glossary_items.dart'
    show GlossaryItems;

part 'glossary_items_dao.g.dart';

/// Data access for [GlossaryItems].
@DriftAccessor(tables: [GlossaryItems])
class GlossaryItemsDao extends DatabaseAccessor<SinceWhenDatabase>
    with _$GlossaryItemsDaoMixin {
  /// Creates the accessor over [database].
  GlossaryItemsDao(SinceWhenDatabase database) : super(database);

  /// Returns all glossary items ordered by tag name.
  Future<List<GlossaryItem>> allItems() => _orderedByTagName().get();

  /// Streams all glossary items ordered by tag name, re-emitting on
  /// change.
  Stream<List<GlossaryItem>> watchAllItems() => _orderedByTagName().watch();

  /// Returns the colors of all glossary items.
  Future<Set<int>> allColorInts() async {
    final query = selectOnly(glossaryItems)
      ..addColumns([glossaryItems.colorInt]);
    final rows = await query.get();
    return rows.map((row) => row.read(glossaryItems.colorInt)!).toSet();
  }

  /// Returns the total number of glossary items.
  Future<int> itemCount() => glossaryItems.count().getSingle();

  /// Streams the total number of glossary items, re-emitting on change.
  Stream<int> watchItemCount() => glossaryItems.count().watchSingle();

  /// Returns the item whose color matches [colorInt], or `null` when no
  /// item uses that color.
  Future<GlossaryItem?> itemWithColor(int colorInt) => (select(
    glossaryItems,
  )..where((item) => item.colorInt.equals(colorInt))).getSingleOrNull();

  /// Selects all items ordered by tag name.
  SimpleSelectStatement<$GlossaryItemsTable, GlossaryItem>
  _orderedByTagName() =>
      select(glossaryItems)
        ..orderBy([(item) => OrderingTerm.asc(item.tagName)]);
}

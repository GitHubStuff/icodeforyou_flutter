// packages/dependency_resolver/lib/src/get_it_dependency_resolver.dart

import 'package:dependency_resolver/src/dependency_resolver.dart';
import 'package:get_it/get_it.dart';

/// Production [DependencyResolver] backed by [GetIt].
///
/// Delegates every resolution to the wrapped [GetIt] instance. Production
/// wiring is unchanged: register services against `GetIt.I` at the
/// composition root, then hand consumers a [GetItDependencyResolver].
final class GetItDependencyResolver implements DependencyResolver {
  /// Creates a resolver delegating to [getIt].
  ///
  /// Defaults to [GetIt.instance] so production construction requires no
  /// arguments. Inject a scoped instance (for example
  /// `GetIt.asNewInstance()`) for integration tests that exercise real
  /// registrations in isolation.
  GetItDependencyResolver({GetIt? getIt}) : _getIt = getIt ?? GetIt.instance;

  final GetIt _getIt;

  @override
  T get<T extends Object>({String? instanceName}) =>
      _getIt.get<T>(instanceName: instanceName);

  @override
  bool isRegistered<T extends Object>({String? instanceName}) =>
      _getIt.isRegistered<T>(instanceName: instanceName);
}

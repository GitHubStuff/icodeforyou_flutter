// ignore_for_file: public_member_api_docs

import 'package:application_startup/new/errors.dart'
    show DuplicateServiceItem;
import 'package:flutter_bloc/flutter_bloc.dart'
    show BlocBuilder, BlocProvider, Cubit;

enum ServiceItemStatus {
  loaded,
  building,
  ready,
  waiting,
}

abstract class BaseServiceStatus {
  const BaseServiceStatus({required this.status});
  final ServiceItemStatus status;
}

sealed class ServiceStatus extends BaseServiceStatus {
  const ServiceStatus({required super.status});
  BaseServiceItem get serviceItem;
}

final class ServicesEmpty extends ServiceStatus {
  ServicesEmpty() : super(status: .waiting);

  @override
  BaseServiceItem<Object> get serviceItem => throw UnimplementedError();
}

final class ServiceItemLoaded extends ServiceStatus {
  const ServiceItemLoaded(
    BaseServiceItem serviceItem,
  ) : _serviceItem = serviceItem,
      super(status: .loaded);

  final BaseServiceItem _serviceItem;

  @override
  BaseServiceItem get serviceItem => _serviceItem;
}

// ----------------------------------------------------------------------------
abstract class BaseServiceProvider {
  void load(BaseServiceItem serviceItem);
}

class GetItServiceProvider extends BaseServiceProvider {
  GetItServiceProvider._();

  static final GetItServiceProvider _instance = GetItServiceProvider._();
  static GetItServiceProvider get P => _instance;

  final Map<String, BaseServiceItem> _providers = {};

  @override
  void load(BaseServiceItem serviceItem) {
    if (_providers[serviceItem.name] != null) {
      throw DuplicateServiceItem(serviceItem.name);
    }
    _providers[serviceItem.name] = serviceItem;
  }
}

// ----------------------------------------------------------------------------

class ServiceProviderCubit extends Cubit<ServiceStatus> {
  ServiceProviderCubit({required BaseServiceProvider using})
    : provider = using,
      super(ServicesEmpty());
  final BaseServiceProvider provider;

  void load(BaseServiceItem serviceItem) {
    provider.load(serviceItem);
    emit(ServiceItemLoaded(serviceItem));
  }
}

// ----------------------------------------------------------------------------
abstract class BaseServiceItem<SRV extends Object> {
  String get name;
  abstract ServiceItemStatus status;
}

//-----
class ThemeServiceItem extends BaseServiceItem {
  @override
  String name = 'ThemeService';

  @override
  ServiceItemStatus status = .loaded;
}

//------------------------------------------------------------------------------
enum ThemeState { dark, light, system }

void hammer() {
  final p = GetItServiceProvider.P;

  final ServiceProviderCubit cubit = ServiceProviderCubit(using: p);

  final ThemeServiceItem themeServiceItem = ThemeServiceItem();

  cubit.load(themeServiceItem);
}

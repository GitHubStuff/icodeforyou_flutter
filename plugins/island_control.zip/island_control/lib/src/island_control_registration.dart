import 'package:island_control/src/island_control.dart';
import 'package:services_provider/services_provider.dart' show ServiceProvider;

/// Registers [IslandControl] in [provider] if it is not already registered.
///
/// Call once from the app's composition root before resolving
/// [IslandControl]. The container is passed in rather than looked up, so
/// any [ServiceProvider] implementation can be used, including an
/// in-memory fake in tests.
void registerIslandControl(ServiceProvider provider) {
  if (provider.isRegistered<IslandControl>()) {
    return;
  }
  provider.registerLazySingleton<IslandControl>(SystemChromeIslandControl.new);
}

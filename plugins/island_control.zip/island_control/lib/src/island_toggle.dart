import 'package:flutter/material.dart';
import 'package:island_control/src/island_control.dart';

/// A single switch: on hides the island, off shows it.
class IslandToggle extends StatefulWidget {
  /// Creates a switch bound to [islandControl], starting at
  /// [initialIsHidden].
  const IslandToggle({
    required this.islandControl,
    this.initialIsHidden = false,
    super.key,
  });

  /// The service that shows or hides the island.
  final IslandControl islandControl;

  /// Whether the island is already hidden when this widget is first built.
  final bool initialIsHidden;

  @override
  State<IslandToggle> createState() => _IslandToggleState();
}

class _IslandToggleState extends State<IslandToggle> {
  late bool _isHidden = widget.initialIsHidden;

  Future<void> _onChanged(bool isHidden) async {
    await widget.islandControl.setIsland(isHidden: isHidden);
    if (!mounted) {
      return;
    }
    setState(() => _isHidden = isHidden);
  }

  @override
  Widget build(BuildContext context) {
    return Switch(value: _isHidden, onChanged: _onChanged);
  }
}

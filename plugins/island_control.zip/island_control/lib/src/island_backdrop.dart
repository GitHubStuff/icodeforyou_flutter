// plugins/island_control/lib/src/island_backdrop.dart
import 'package:flutter/material.dart';

/// Paints the island (top system inset) black and lays [child] out below it.
///
/// When the island is hidden the top inset is zero, so the band collapses
/// and [child] fills the screen with no extra configuration.
class IslandBackdrop extends StatelessWidget {
  /// Creates a black backdrop for the island above [child].
  const IslandBackdrop({required this.child, super.key});

  /// The content shown below the island.
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final islandHeight = MediaQuery.viewPaddingOf(context).top;

    return ColoredBox(
      color: Colors.black,
      child: Padding(
        padding: EdgeInsets.only(top: islandHeight),
        child: MediaQuery.removePadding(
          context: context,
          removeTop: true,
          child: child,
        ),
      ),
    );
  }
}

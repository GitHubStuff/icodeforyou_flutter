// plugins/island_control/lib/src/island_control.dart
// ignore_for_file: one_member_abstracts

import 'package:flutter/services.dart';

/// Signature of [SystemChrome.setEnabledSystemUIMode].
typedef SetSystemUiMode = Future<void> Function(
  SystemUiMode mode, {
  List<SystemUiOverlay>? overlays,
});

/// Signature of [SystemChrome.setSystemUIOverlayStyle].
typedef SetSystemUiOverlayStyle = void Function(SystemUiOverlayStyle style);

/// Shows or hides the Android status bar ("island").
abstract interface class IslandControl {
  /// Hides the island when [isHidden] is `true`, shows it otherwise.
  Future<void> setIsland({required bool isHidden});
}

/// [IslandControl] backed by [SystemChrome].
///
/// The [SystemChrome] statics are injectable so the class can be unit
/// tested without a platform channel.
class SystemChromeIslandControl implements IslandControl {
  /// Creates an [IslandControl] that delegates to [SystemChrome].
  SystemChromeIslandControl({
    SetSystemUiMode? setMode,
    SetSystemUiOverlayStyle? setStyle,
  }) : _setMode = setMode ?? SystemChrome.setEnabledSystemUIMode,
       _setStyle = setStyle ?? SystemChrome.setSystemUIOverlayStyle;

  static const SystemUiOverlayStyle _shownStyle = SystemUiOverlayStyle(
    statusBarColor: Color(0xFF000000),
    statusBarIconBrightness: Brightness.light,
    statusBarBrightness: Brightness.dark,
  );

  final SetSystemUiMode _setMode;
  final SetSystemUiOverlayStyle _setStyle;

  @override
  Future<void> setIsland({required bool isHidden}) async {
    if (isHidden) {
      await _setMode(SystemUiMode.immersiveSticky);
      return;
    }
    await _setMode(SystemUiMode.manual, overlays: SystemUiOverlay.values);
    _setStyle(_shownStyle);
  }
}

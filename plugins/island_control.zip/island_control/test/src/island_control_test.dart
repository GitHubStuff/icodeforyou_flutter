import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:island_control/src/island_control.dart';

typedef ModeCall = ({SystemUiMode mode, List<SystemUiOverlay>? overlays});

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('SystemChromeIslandControl', () {
    group('with injected SystemChrome delegates', () {
      late List<ModeCall> modeCalls;
      late List<SystemUiOverlayStyle> styles;
      late SystemChromeIslandControl control;

      setUp(() {
        modeCalls = <ModeCall>[];
        styles = <SystemUiOverlayStyle>[];
        control = SystemChromeIslandControl(
          setMode:
              (
                SystemUiMode mode, {
                List<SystemUiOverlay>? overlays,
              }) async {
                modeCalls.add((mode: mode, overlays: overlays));
              },
          setStyle: styles.add,
        );
      });

      test('setIsland(isHidden: true) enters immersive sticky mode', () async {
        await control.setIsland(isHidden: true);

        expect(modeCalls, hasLength(1));
        expect(modeCalls.single.mode, SystemUiMode.immersiveSticky);
        expect(modeCalls.single.overlays, isNull);
        expect(styles, isEmpty);
      });

      test('setIsland(isHidden: false) shows all overlays in black', () async {
        await control.setIsland(isHidden: false);

        expect(modeCalls, hasLength(1));
        expect(modeCalls.single.mode, SystemUiMode.manual);
        expect(modeCalls.single.overlays, SystemUiOverlay.values);
        expect(styles, hasLength(1));
        expect(styles.single.statusBarColor, const Color(0xFF000000));
        expect(styles.single.statusBarIconBrightness, Brightness.light);
        expect(styles.single.statusBarBrightness, Brightness.dark);
      });
    });

    group('with default SystemChrome delegates', () {
      late List<MethodCall> calls;

      setUp(() {
        calls = <MethodCall>[];
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(SystemChannels.platform, (call) async {
              calls.add(call);
              return null;
            });
      });

      tearDown(() {
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(SystemChannels.platform, null);
      });

      test('setIsland(isHidden: true) reaches the platform channel', () async {
        await SystemChromeIslandControl().setIsland(isHidden: true);

        expect(
          calls.map((call) => call.method),
          <String>['SystemChrome.setEnabledSystemUIMode'],
        );
      });

      test('setIsland(isHidden: false) reaches the platform channel', () async {
        await SystemChromeIslandControl().setIsland(isHidden: false);
        await Future<void>.delayed(Duration.zero);

        expect(
          calls.map((call) => call.method),
          <String>[
            'SystemChrome.setEnabledSystemUIOverlays',
            'SystemChrome.setSystemUIOverlayStyle',
          ],
        );
      });
    });
  });
}

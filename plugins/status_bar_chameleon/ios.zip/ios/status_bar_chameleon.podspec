#
# To learn more about a Podspec see http://guides.cocoapods.org/syntax/podspec.html.
# Run `pod lib lint status_bar_chameleon.podspec` to validate before publishing.
#
Pod::Spec.new do |s|
  s.name             = 'status_bar_chameleon'
  s.version          = '0.0.1'
  s.summary          = 'A new Flutter plugin project.'
  s.description      = <<-DESC
A new Flutter plugin project.
                       DESC
  s.homepage         = 'http://example.com'
  s.license          = { :file => '../LICENSE' }
  s.author           = { 'Your Company' => 'email@example.com' }
  s.source           = { :path => '.' }
  s.source_files = 'status_bar_chameleon/Sources/status_bar_chameleon/**/*.swift'
  s.dependency 'Flutter'
  s.platform = :ios, '13.0'
# Flutter.framework does not contain a i386 slice.
  s.pod_target_xcconfig = { 'DEFINES_MODULE' => 'YES', 'EXCLUDED_ARCHS[sdk=iphonesimulator*]' => 'i386' }
  s.swift_version = '5.0'
  s.resource_bundles = {'status_bar_chameleon_privacy' => ['status_bar_chameleon/Sources/status_bar_chameleon/Resources/PrivacyInfo.xcprivacy']}
end